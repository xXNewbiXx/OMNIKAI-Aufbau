Nach dem Import sollten hier Dateien landen:
- `*.outline.md`
- `*.graph.json`
- `*.actions.md`

Wenn leer: Prüfe Pfad `/uploads/manus/mindmaps/**` und die Stage `mindmap_ingest`.
